// features/selectPersonality.js
const {
    SlashCommandBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    ActionRowBuilder
  } = require("discord.js");
  
  const data = new SlashCommandBuilder()
    .setName("select-personality")
    .setDescription("Choose the chatbot's personality using a select menu");
  
  async function run({ interaction }) {
    const personalities = [
      { label: "Study Partner", value: "study", description: "A helpful chatbot that loves to help you study." },
      { label: "Nice",          value: "nice",  description: "A warm, friendly chatbot." },
      { label: "Witty",         value: "witty", description: "A chatbot with clever jokes and humor." },
      // Add more if desired
    ];
  
    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId(`select-personality-${interaction.id}`)
      .setPlaceholder("Choose a chatbot personality...")
      .setMaxValues(1)
      .addOptions(
        personalities.map(p =>
          new StringSelectMenuOptionBuilder()
            .setLabel(p.label)
            .setDescription(p.description)
            .setValue(p.value)
        )
      );
  
    const actionRow = new ActionRowBuilder().addComponents(selectMenu);
  
    await interaction.reply({ components: [actionRow], ephemeral: true });
  }
  
  module.exports = {
    data,
    run
  };
  