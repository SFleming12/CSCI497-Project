// features/pomodoro.js

async function handlePomodoroCommands(message) {
    const lower = message.content.trim().toLowerCase();
    if (!lower.startsWith('pomodoro')) {
      return false;
    }
  
    const parts = message.content.split(/\s+/);
    let minutes = 25;
    if (parts.length > 1) {
      const parsed = parseInt(parts[1], 10);
      if (!isNaN(parsed) && parsed > 0) {
        minutes = parsed;
      }
    }
  
    await message.reply(`Pomodoro timer started for ${minutes} minute${minutes === 1 ? '' : 's'}! I'll remind you when it's over.`);
    setTimeout(() => {
      message.channel.send(`${message.author}, your Pomodoro session is over! Time for a break.`);
    }, minutes * 60 * 1000);
  
    return true;
  }
  
  module.exports = {
    handlePomodoroCommands
  };
  