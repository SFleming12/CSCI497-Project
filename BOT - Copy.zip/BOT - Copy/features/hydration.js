// features/hydration.js
const fs = require('fs');
const path = require('path');

let hydrationReminders = {};
const HYDRATION_DATA_FILE = path.join(__dirname, '..', 'hydrationData.json');

const RANDOM_HYDRATION_MESSAGES = [
  "Time to drink some water!",
  "Grab a sip and keep going!",
  "Stay hydrated, friend!",
  "Don’t forget to hydrate!",
  "Water break time!",
];

function loadHydrationReminders() {
  if (!fs.existsSync(HYDRATION_DATA_FILE)) return;
  const content = fs.readFileSync(HYDRATION_DATA_FILE, 'utf-8');
  if (!content) return;

  try {
    const data = JSON.parse(content);
    for (const userId in data) {
      hydrationReminders[userId] = {
        ...data[userId],
        timeouts: [],
        midnightTimeout: null
      };
    }
  } catch (err) {
    console.error("Failed to parse hydrationData.json:", err);
  }
}

function saveHydrationReminders() {
  const dataToSave = {};
  for (const userId in hydrationReminders) {
    const { startHour, endHour, intervalHours, isPaused, channelId, stats } = hydrationReminders[userId];
    dataToSave[userId] = { startHour, endHour, intervalHours, isPaused, channelId, stats };
  }
  fs.writeFileSync(HYDRATION_DATA_FILE, JSON.stringify(dataToSave, null, 2), 'utf-8');
}

function cancelAllRemindersForUser(userId) {
  const data = hydrationReminders[userId];
  if (!data) return;

  if (data.timeouts) {
    data.timeouts.forEach(t => clearTimeout(t));
    data.timeouts = [];
  }
  if (data.midnightTimeout) {
    clearTimeout(data.midnightTimeout);
    data.midnightTimeout = null;
  }
}

async function getReminderChannel(client, userId) {
  const data = hydrationReminders[userId];
  if (!data || !data.channelId) return null;

  if (data.channelId === 'dm') {
    const user = await client.users.fetch(userId).catch(() => null);
    if (!user) return null;
    return user.createDM();
  }
  return client.channels.fetch(data.channelId).catch(() => null);
}

async function scheduleHydrationRemindersForToday(client, userId) {
  const data = hydrationReminders[userId];
  if (!data) return;

  const channel = await getReminderChannel(client, userId);
  if (!channel) return;

  const now = new Date();
  let hour = data.startHour;
  while (hour <= data.endHour) {
    const reminderTime = new Date();
    reminderTime.setHours(hour, 0, 0, 0);

    if (reminderTime > now) {
      const msUntil = reminderTime - now;
      const timeoutId = setTimeout(() => {
        const d = hydrationReminders[userId];
        if (d && !d.isPaused) {
          const randomMsg = RANDOM_HYDRATION_MESSAGES[
            Math.floor(Math.random() * RANDOM_HYDRATION_MESSAGES.length)
          ];
          channel.send(`<@${userId}> ${randomMsg} (Scheduled reminder)`);
        }
      }, msUntil);
      data.timeouts.push(timeoutId);
    }
    hour += data.intervalHours || 2;
  }

  // Schedule midnight reset
  const nextMidnight = new Date();
  nextMidnight.setHours(24, 0, 0, 0);
  const msUntilMidnight = nextMidnight - now;
  data.midnightTimeout = setTimeout(() => {
    data.timeouts = [];
    scheduleHydrationRemindersForToday(client, userId);
  }, msUntilMidnight);
}

async function startHydrationReminders(client, userId, startHour, endHour, intervalHours, channelChoice) {
  if (!hydrationReminders[userId]) {
    hydrationReminders[userId] = {
      startHour,
      endHour,
      intervalHours,
      isPaused: false,
      channelId: channelChoice,
      stats: { count: 0, streak: 0, lastHydrated: null },
      timeouts: [],
      midnightTimeout: null
    };
  } else {
    const data = hydrationReminders[userId];
    data.startHour = startHour;
    data.endHour = endHour;
    data.intervalHours = intervalHours;
    data.channelId = channelChoice;
    data.isPaused = false;
  }

  cancelAllRemindersForUser(userId);
  await scheduleHydrationRemindersForToday(client, userId);
  saveHydrationReminders();
}

async function rescheduleAllRemindersOnStartup(client) {
  for (const userId in hydrationReminders) {
    const data = hydrationReminders[userId];
    if (!data.isPaused && data.channelId) {
      await scheduleHydrationRemindersForToday(client, userId);
    }
  }
}

async function onBotReady(client) {
  loadHydrationReminders();
  await rescheduleAllRemindersOnStartup(client);
}

async function handleHydrationCommands(message, client) {
  const content = message.content.trim().toLowerCase();

  if (content.startsWith("start hydration reminders")) {
    const parts = message.content.split(/\s+/);
    if (parts.length < 5) {
      await message.reply("Usage: `start hydration reminders 8 20 [2] [dm]`");
      return true;
    }

    const startHour = parseInt(parts[3], 10);
    const endHour = parseInt(parts[4], 10);
    let interval = 2;
    let dmChoice = false;

    if (parts[5] && !isNaN(parseInt(parts[5], 10))) {
      interval = parseInt(parts[5], 10);
      if (parts[6] && parts[6].toLowerCase() === 'dm') {
        dmChoice = true;
      }
    } else if (parts[5] && parts[5].toLowerCase() === 'dm') {
      dmChoice = true;
    }

    if (
      isNaN(startHour) ||
      isNaN(endHour) ||
      startHour < 0 || startHour > 23 ||
      endHour < 0 || endHour > 23 ||
      startHour > endHour
    ) {
      await message.reply("Invalid time range. Use 24-hour format, e.g. `start hydration reminders 8 20`");
      return true;
    }

    const channelChoice = dmChoice ? 'dm' : message.channelId;
    await startHydrationReminders(client, message.author.id, startHour, endHour, interval, channelChoice);
    await message.reply(`Hydration reminders set from **${startHour}:00** to **${endHour}:00** every **${interval}** hour(s).${dmChoice ? " (Check DMs!)" : ""}`);

    return true;
  }

  if (content.startsWith("stop hydration reminders")) {
    cancelAllRemindersForUser(message.author.id);
    delete hydrationReminders[message.author.id];
    saveHydrationReminders();
    await message.reply("Hydration reminders have been stopped and cleared.");
    return true;
  }

  if (content.startsWith("pause hydration reminders")) {
    const data = hydrationReminders[message.author.id];
    if (!data) {
      await message.reply("You have no active hydration reminders to pause.");
      return true;
    }
    data.isPaused = true;
    if (data.timeouts) {
      data.timeouts.forEach(t => clearTimeout(t));
      data.timeouts = [];
    }
    saveHydrationReminders();
    await message.reply("Your hydration reminders are now paused.");
    return true;
  }

  if (content.startsWith("resume hydration reminders")) {
    const data = hydrationReminders[message.author.id];
    if (!data) {
      await message.reply("No hydration reminders found to resume. Start them first.");
      return true;
    }
    if (!data.isPaused) {
      await message.reply("Your hydration reminders are already running.");
      return true;
    }
    data.isPaused = false;
    cancelAllRemindersForUser(message.author.id);
    await scheduleHydrationRemindersForToday(client, message.author.id);
    saveHydrationReminders();
    await message.reply("Your hydration reminders have resumed.");
    return true;
  }

  if (content.startsWith("show hydration reminders")) {
    const data = hydrationReminders[message.author.id];
    if (!data) {
      await message.reply("No hydration reminders configured.");
      return true;
    }
    const { startHour, endHour, intervalHours, isPaused, stats } = data;
    const status = isPaused ? "Paused" : "Active";
    let response = `**Hydration Reminders**\n`
      + `Start Hour: ${startHour}\n`
      + `End Hour: ${endHour}\n`
      + `Interval: ${intervalHours}\n`
      + `Status: ${status}\n\n`
      + `**Hydration Stats**\n`
      + `Count: ${stats?.count ?? 0}\n`
      + `Streak: ${stats?.streak ?? 0}\n`;
    await message.reply(response);
    return true;
  }

  if (content.startsWith("i hydrated")) {
    const data = hydrationReminders[message.author.id];
    if (!data) {
      await message.reply("You have no hydration reminders set. Start them first.");
      return true;
    }
    const now = Date.now();
    const last = data.stats.lastHydrated || 0;
    const hoursSinceLast = (now - last) / (1000 * 60 * 60);

    if (hoursSinceLast < 6) {
      data.stats.streak += 1;
    } else {
      data.stats.streak = 1;
    }
    data.stats.count += 1;
    data.stats.lastHydrated = now;

    saveHydrationReminders();
    await message.reply(`Great job! You've hydrated **${data.stats.count}** times. Your streak is now **${data.stats.streak}**.`);
    return true;
  }

  return false;
}

module.exports = {
  onBotReady,
  handleHydrationCommands
};
