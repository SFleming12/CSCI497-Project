// features/eightBall.js
const { SlashCommandBuilder } = require("discord.js");
const { userPersonalities } = require("./chatgpt");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("8ball")
    .setDescription("Ask the magic 8-ball a question")
    .addStringOption(option =>
      option
        .setName("question")
        .setDescription("Ask your question to the magic 8-ball")
        .setRequired(true)
    ),

  async run(context) {
    const interaction = context.interaction || context;
    if (!interaction) return;

    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "witty") {
      await interaction.reply({
        content: "You must have the **witty** personality selected to use /8ball!",
        ephemeral: true
      });
      return;
    }

    const question = interaction.options.getString("question");
    if (!question) {
      await interaction.reply("Please provide a question for the 8-ball!");
      return;
    }

    if (typeof interaction.deferReply === "function") {
      await interaction.deferReply();
    }

    const responses = [
      "It is certain",
      "It is decidedly so",
      "Without a doubt",
      "Yes, definitely",
      "You may rely on it",
      "As I see it, yes",
      "Most likely",
      "Outlook good",
      "Yes",
      "Signs point to yes",
      "Reply hazy, try again",
      "Ask again later",
      "Better not tell you now",
      "Cannot predict now",
      "Concentrate and ask again",
      "Don't count on it",
      "My reply is no",
      "My sources say no",
      "Outlook not so good",
      "Very doubtful"
    ];
    const randomResponse = responses[Math.floor(Math.random() * responses.length)];

    if (typeof interaction.editReply === "function") {
      await interaction.editReply(`🎱 **Magic 8-ball says:** ${randomResponse}`);
    } else {
      await interaction.reply(`🎱 **Magic 8-ball says:** ${randomResponse}`);
    }
  },
};
