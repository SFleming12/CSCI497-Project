// features/roast.js
const { SlashCommandBuilder } = require("discord.js");
const { OpenAI } = require("openai");
const { userPersonalities } = require("./chatgpt");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_KEY,
});

module.exports = {
  data: new SlashCommandBuilder()
    .setName("roast")
    .setDescription("Generates a witty roast for a user")
    .addUserOption(option =>
      option
        .setName("target")
        .setDescription("The user to roast")
        .setRequired(true)
    ),

  async run(context) {
    const interaction = context.interaction || context;
    if (!interaction) return;

    const personality = userPersonalities.get(interaction.user.id);
    if (personality !== "witty") {
      await interaction.reply({
        content: "You must select the **witty** personality to use `/roast`!",
        ephemeral: true
      });
      return;
    }

    const targetUser = interaction.options.getUser("target");
    if (!targetUser) {
      await interaction.reply("I need someone to roast!");
      return;
    }

    if (typeof interaction.deferReply === "function") {
      await interaction.deferReply();
    }

    const roastPrompt = `Generate a funny, lighthearted roast for the Discord user named ${targetUser.username}. Keep it witty but not offensive.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [{ role: "system", content: roastPrompt }],
      });
      const roast = response.choices[0].message.content.trim();

      if (typeof interaction.editReply === "function") {
        await interaction.editReply(`🔥 **${targetUser.username}**, ${roast}`);
      } else {
        await interaction.reply(`🔥 **${targetUser.username}**, ${roast}`);
      }
    } catch (error) {
      console.error("OpenAI Error:", error);
      if (typeof interaction.editReply === "function") {
        await interaction.editReply("Oops! I failed to deliver the burn.");
      } else {
        await interaction.reply("Oops! I failed to deliver the burn.");
      }
    }
  },
};
