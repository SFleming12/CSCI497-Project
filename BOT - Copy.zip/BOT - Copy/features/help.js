// features/help.js

function getHelpText() {
    return (
      "**List of Commands:**\n\n" +
      // ...
      "**/select-personality**\n" +
      "→ Pick a personality for the bot (study, witty, etc.).\n\n" +
  
      "**/8ball [question]**\n" +
      "→ Ask the magic 8-ball. Must be witty.\n\n" +
  
      "**/roast @User**\n" +
      "→ Generate a witty roast. Must be witty.\n\n" +
  
      "**/fortune**\n" +
      "→ Receive a witty fortune. Must be witty.\n\n" +
  
      "**/bants [message]**\n" +
      "→ Generate a witty, playful roast based on a message. Must be witty.\n\n" +
  
      // ...
      "**(anything else)**\n" +
      "→ Forwarded to ChatGPT with your chosen personality.\n"
    );
  }
  
  async function handleHelpCommands(message) {
    const lower = message.content.trim().toLowerCase();
    if (lower === 'help' || lower === 'help menu') {
      await message.reply(getHelpText());
      return true;
    }
    return false;
  }
  
  module.exports = {
    handleHelpCommands
  };
  