require('dotenv/config');
const { Client, GatewayIntentBits, REST, Routes } = require('discord.js');

// Text-based features
const { onBotReady, handleHydrationCommands } = require('./features/hydration');
const { handleHelpCommands } = require('./features/help');
const { handlePomodoroCommands } = require('./features/pomodoro');
const { handleChatGpt, userPersonalities } = require('./features/chatgpt');

// Slash-based features
const eightBall = require('./features/eightBall');
const roast = require('./features/roast');
const fortune = require('./features/fortune');
const selectPersonality = require('./features/selectPersonality');
const banter = require('./features/banter'); // new import

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.once('ready', async () => {
  console.log("Bot is online");

  // 1) Hydration setup
  await onBotReady(client);

  // 2) Register slash commands
  const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

  // Collect slash commands
  const commandsData = [
    eightBall.data.toJSON(),
    roast.data.toJSON(),
    fortune.data.toJSON(),
    selectPersonality.data.toJSON(),
    banter.data.toJSON() // /bants command
  ];

  try {
    console.log("Registering slash commands (guild)...");
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commandsData }
    );
    console.log("Slash commands registered successfully (guild)!");
  } catch (error) {
    console.error("Failed to register slash commands:", error);
  }
});

// 3) Handle interactions
client.on('interactionCreate', async (interaction) => {
  // Slash commands
  if (interaction.isChatInputCommand()) {
    if (interaction.commandName === '8ball') {
      await eightBall.run({ interaction });
      return;
    }
    if (interaction.commandName === 'roast') {
      await roast.run({ interaction });
      return;
    }
    if (interaction.commandName === 'fortune') {
      await fortune.run({ interaction });
      return;
    }
    if (interaction.commandName === 'select-personality') {
      await selectPersonality.run({ interaction });
      return;
    }
    if (interaction.commandName === 'bants') {
      await banter.run({ interaction });
      return;
    }
    return;
  }

  // If user picks a personality from the dropdown
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId.startsWith('select-personality-')) {
      const selectedValue = interaction.values[0]; // e.g. "study", "witty"
      userPersonalities.set(interaction.user.id, selectedValue);
      await interaction.reply({
        content: `Your personality is now set to **${selectedValue}**!`,
        ephemeral: true
      });
    }
  }
});

// 4) Text-based commands
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  if (await handleHelpCommands(message)) return;
  if (await handleHydrationCommands(message, client)) return;
  if (await handlePomodoroCommands(message)) return;

  await handleChatGpt(message);
});

client.login(process.env.TOKEN);
