// features/banter.js

// Import the necessary classes from discord.js for building a slash command.
const { SlashCommandBuilder } = require("discord.js");
// Import OpenAI class to interact with the OpenAI API.
const { OpenAI } = require("openai");
// Import the userPersonalities map from our chatgpt module to check the user's selected personality.
const { userPersonalities } = require("./chatgpt");

// Create an instance of the OpenAI client with your API key from the .env file.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_KEY, // ensure this matches your .env variable
});

module.exports = {
  // Define the slash command using the builder.
  data: new SlashCommandBuilder()
    .setName("bants")
    .setDescription("Playfully roast yourself or someone else based on a message.")
    .addStringOption(option =>
      option
        .setName("message")
        .setDescription("The message to roast, could be about anything!")
        .setRequired(true)
    ),

  // The command execution function.
  async run(context) {
    // Grab the Discord interaction from the context.
    const discordInteraction = context.interaction || context;
    if (!discordInteraction) return;

    // Check that the interaction options can be read (i.e. the command was used correctly).
    if (
      !discordInteraction.options ||
      typeof discordInteraction.options.getString !== "function"
    ) {
      console.error("Interaction options are not available.");
      return "Something went wrong: command options are not available.";
    }

    // Retrieve the user's provided message.
    const userMessage = discordInteraction.options.getString("message");
    if (!userMessage) {
      await discordInteraction.reply("Please provide a message to roast!");
      return;
    }

    // Check if the user has the correct personality ("witty") to use this command.
    const selectedPersonality = userPersonalities.get(discordInteraction.user.id);
    if (selectedPersonality !== "witty") {
      await discordInteraction.reply({
        content: "You must select the **witty** personality to use `/bants`!",
        ephemeral: true, // Only the user will see this message.
      });
      return;
    }

    // Optionally defer the reply if the interaction supports it (helps if the API call takes time).
    if (typeof discordInteraction.deferReply === "function") {
      await discordInteraction.deferReply();
    }

    // Use the user's username in the prompt.
    const targetUser = discordInteraction.user;
    // Build a prompt for the OpenAI API that asks for a witty roast.
    const bantsPrompt = `Generate a witty, playful roast based on the following message by ${targetUser.username}: "${userMessage}". Keep it fun, lighthearted, and clever but not offensive. This roast should be something that could be said in a friendly banter between friends.`;

    try {
      // Send a request to the OpenAI API using the GPT-3.5-turbo model.
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [{ role: "system", content: bantsPrompt }],
      });
      // Extract the generated roast from the response.
      const bants = response.choices[0].message.content;

      // If we can edit the deferred reply, use it; otherwise, return the string.
      if (typeof discordInteraction.editReply === "function") {
        await discordInteraction.editReply(`🔥${bants}`);
      } else {
        return `🔥 **Bants**: ${bants}`;
      }
    } catch (error) {
      console.error("OpenAI Error:", error);
      // If there's an error, reply with an error message.
      if (typeof discordInteraction.editReply === "function") {
        await discordInteraction.editReply("Oops! I failed to deliver the bants.");
      } else {
        return "Oops! I failed to deliver the bants.";
      }
    }
  },
};
