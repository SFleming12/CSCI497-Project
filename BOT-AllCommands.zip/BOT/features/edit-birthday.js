// features/edit-birthday.js

// Import the SlashCommandBuilder from discord.js for building the command.
const { SlashCommandBuilder } = require("discord.js");
// Import the userPersonalities map to check personality.
const { userPersonalities } = require("./chatgpt");
// Import the setBirthday function from birthdayStore to update birthday data.
const { setBirthday } = require("./birthdayStore");

module.exports = {
  // Define the slash command with a name and description.
  data: new SlashCommandBuilder()
    .setName("edit-birthday")
    .setDescription("Edit your set birthday date"),
  async run({ interaction }) {
    // Check if the user's personality is "nice"; required for birthday commands.
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply({
        content: "You must select the **nice** personality to use `/edit-birthday`!",
        ephemeral: true,
      });
    }
    // Ask the user for their new birthday.
    await interaction.reply({
      content: "Enter your new birthday in MM-DD format:",
      ephemeral: true,
    });
    // Create a filter to only accept messages from the same user.
    const filter = (msg) => msg.author.id === interaction.user.id;
    // Wait for the user's message (up to 1 minute, 1 message).
    const collected = await interaction.channel.awaitMessages({
      filter,
      time: 60000,
      max: 1,
    });
    if (collected.size === 0) {
      return interaction.followUp("Time's up! Please try again.");
    }
    // Get and trim the new birthday input.
    const newBirthday = collected.first().content.trim();
    // Validate the birthday format (MM-DD).
    const birthdayRegex = /^\d{2}-\d{2}$/;
    if (!birthdayRegex.test(newBirthday)) {
      return interaction.followUp("Invalid format! Please use MM-DD format.");
    }
    // Update the birthday in the persistent store.
    setBirthday(interaction.user.id, newBirthday);
    // Inform the user of the successful update.
    await interaction.followUp(`Your birthday has been updated to **${newBirthday}**.`);
  },
};
