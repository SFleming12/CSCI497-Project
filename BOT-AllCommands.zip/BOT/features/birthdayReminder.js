// features/birthdayReminder.js

// Import OpenAI to generate birthday messages.
const { OpenAI } = require("openai");
// Import getAllBirthdays from our birthdayStore module to load birthday data from a JSON file.
const { getAllBirthdays } = require("./birthdayStore");

// Create an OpenAI client instance using the API key from .env.
const openai = new OpenAI({ apiKey: process.env.OPENAI_KEY });

/**
 * checkBirthdays: Scans all stored birthdays and sends a birthday message
 * if today matches a user's birthday.
 */
async function checkBirthdays(client) {
  // Load all birthday data.
  const birthdays = getAllBirthdays();
  const today = new Date();
  // Format today's month and day to MM-DD.
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  const todayStr = `${month}-${day}`;
  
  // Loop through each user in the birthday data.
  for (const userId in birthdays) {
    const birthday = birthdays[userId];
    if (birthday.trim() === todayStr) {
      try {
        // Fetch the user object.
        const user = await client.users.fetch(userId);
        // Request a ChatGPT-generated birthday message.
        const response = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "Generate a cheerful and heartfelt birthday message." },
            { role: "user", content: `Generate a birthday message for ${user.username}` }
          ],
        });
        const birthdayMessage = response.choices[0].message.content;
        // Send the birthday message as a DM to the user.
        user.send(`Happy Birthday, ${user.username}! ${birthdayMessage}`);
      } catch (error) {
        console.error("Error sending birthday message for user", userId, error);
      }
    }
  }
}

/**
 * setupBirthdayReminders: Sets up a daily job to check birthdays.
 */
function setupBirthdayReminders(client) {
  const now = new Date();
  const nextCheck = new Date();
  // Schedule the check to run at 12:05 AM daily.
  nextCheck.setHours(0, 5, 0, 0);
  if (nextCheck < now) {
    nextCheck.setDate(nextCheck.getDate() + 1);
  }
  const delay = nextCheck - now;
  setTimeout(() => {
    checkBirthdays(client);
    // Then schedule it to run every 24 hours.
    setInterval(() => {
      checkBirthdays(client);
    }, 24 * 60 * 60 * 1000);
  }, delay);
}

module.exports = {
  setupBirthdayReminders,
};
