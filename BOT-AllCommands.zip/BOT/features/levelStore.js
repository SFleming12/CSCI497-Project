// features/levelStore.js

const fs = require('fs');
const path = require('path');
// Define the file path for persistent leveling data.
const LEVEL_DATA_FILE = path.join(__dirname, '..', 'levelData.json');

/**
 * loadLevels reads the leveling data from the JSON file.
 */
function loadLevels() {
  if (!fs.existsSync(LEVEL_DATA_FILE)) return {};
  try {
    return JSON.parse(fs.readFileSync(LEVEL_DATA_FILE, 'utf8'));
  } catch (err) {
    console.error("Error loading level data:", err);
    return {};
  }
}

/**
 * saveLevels writes the leveling data object to the JSON file.
 */
function saveLevels(data) {
  fs.writeFileSync(LEVEL_DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

/**
 * getUserLevel retrieves the level for a given user ID.
 */
function getUserLevel(userId) {
  const data = loadLevels();
  return data[userId] ? data[userId].level : 1;
}

/**
 * getUserXP retrieves the XP for a given user ID.
 */
function getUserXP(userId) {
  const data = loadLevels();
  return data[userId] ? data[userId].xp : 0;
}

/**
 * setUserLevel sets the level for a given user ID.
 */
function setUserLevel(userId, level) {
  const data = loadLevels();
  if (!data[userId]) data[userId] = { level: 1, xp: 0 };
  data[userId].level = level;
  saveLevels(data);
}

/**
 * setUserXP sets the XP for a given user ID.
 */
function setUserXP(userId, xp) {
  const data = loadLevels();
  if (!data[userId]) data[userId] = { level: 1, xp: 0 };
  data[userId].xp = xp;
  saveLevels(data);
}

/**
 * resetUser resets a user's level and XP to the defaults.
 */
function resetUser(userId) {
  const data = loadLevels();
  data[userId] = { level: 1, xp: 0 };
  saveLevels(data);
}

module.exports = {
  loadLevels,
  saveLevels,
  getUserLevel,
  getUserXP,
  setUserLevel,
  setUserXP,
  resetUser,
};
