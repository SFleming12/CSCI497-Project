// features/birthdayStore.js

const fs = require('fs');
const path = require('path');
// Define the path to the birthday data JSON file.
const BIRTHDAY_DATA_FILE = path.join(__dirname, '..', 'birthdayData.json');

/**
 * loadBirthdays: Reads the birthday data file and returns an object.
 */
function loadBirthdays() {
  if (!fs.existsSync(BIRTHDAY_DATA_FILE)) return {};
  try {
    return JSON.parse(fs.readFileSync(BIRTHDAY_DATA_FILE, 'utf-8'));
  } catch (err) {
    console.error("Failed to parse birthdayData.json:", err);
    return {};
  }
}

/**
 * saveBirthdays: Saves the given birthday data object to the JSON file.
 */
function saveBirthdays(data) {
  fs.writeFileSync(BIRTHDAY_DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

/**
 * setBirthday: Sets a birthday for a given user ID.
 */
function setBirthday(userId, birthday) {
  const data = loadBirthdays();
  data[userId] = birthday;
  saveBirthdays(data);
}

/**
 * removeBirthday: Removes a birthday for a given user ID.
 */
function removeBirthday(userId) {
  const data = loadBirthdays();
  if (data[userId]) {
    delete data[userId];
    saveBirthdays(data);
    return true;
  }
  return false;
}

/**
 * getBirthday: Retrieves the birthday for a given user ID.
 */
function getBirthday(userId) {
  const data = loadBirthdays();
  return data[userId];
}

/**
 * getAllBirthdays: Returns all stored birthdays.
 */
function getAllBirthdays() {
  return loadBirthdays();
}

module.exports = {
  setBirthday,
  removeBirthday,
  getBirthday,
  getAllBirthdays,
};
