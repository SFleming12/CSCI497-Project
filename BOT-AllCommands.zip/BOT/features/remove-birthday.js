// features/remove-birthday.js

// Import the SlashCommandBuilder for building slash commands.
const { SlashCommandBuilder } = require("discord.js");
// Import the userPersonalities map to check if the user has the correct personality.
const { userPersonalities } = require("./chatgpt");
// Import the removeBirthday function from birthdayStore to remove stored birthday data.
const { removeBirthday } = require("./birthdayStore");

module.exports = {
  // Define the slash command: /remove-birthday.
  data: new SlashCommandBuilder()
    .setName("remove-birthday")
    .setDescription("Remove your set birthday date"),
  async run({ interaction }) {
    // Check if the user's personality is "nice".
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply({
        content: "You must select the **nice** personality to use `/remove-birthday`!",
        ephemeral: true,
      });
    }
    // Remove the birthday using the birthdayStore.
    const success = removeBirthday(interaction.user.id);
    if (success) {
      await interaction.reply({
        content: "Your birthday has been removed successfully.",
        ephemeral: true,
      });
    } else {
      await interaction.reply({
        content: "No birthday found to remove.",
        ephemeral: true,
      });
    }
  },
};
