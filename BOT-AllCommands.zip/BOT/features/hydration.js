// features/hydration.js

// Import the SlashCommandBuilder to define a slash command.
const { SlashCommandBuilder } = require('discord.js');
// Import file system and path modules for data persistence.
const fs = require('fs');
const path = require('path');
// Import userPersonalities to enforce the "study" personality requirement.
const { userPersonalities } = require('./chatgpt');

// Object to hold hydration reminder data in-memory.
let hydrationReminders = {};
// Define the file path for storing hydration data persistently.
const HYDRATION_DATA_FILE = path.join(__dirname, '..', 'hydrationData.json');

// List of possible hydration reminder messages.
const RANDOM_HYDRATION_MESSAGES = [
  "Time to drink some water!",
  "Grab a sip and keep going!",
  "Stay hydrated, friend!",
  "Don’t forget to hydrate!",
  "Water break time!",
];

// ------------------ Persistence Functions ------------------

/**
 * loadHydrationReminders reads the JSON file and loads the data into memory.
 */
function loadHydrationReminders() {
  if (!fs.existsSync(HYDRATION_DATA_FILE)) return;
  try {
    const savedData = JSON.parse(fs.readFileSync(HYDRATION_DATA_FILE, 'utf-8'));
    for (const userId in savedData) {
      hydrationReminders[userId] = { ...savedData[userId], timeouts: [], midnightTimeout: null };
    }
  } catch (err) {
    console.error("Failed to load hydrationData.json:", err);
  }
}

/**
 * saveHydrationReminders writes the in-memory hydration data to the JSON file.
 */
function saveHydrationReminders() {
  const dataToSave = {};
  for (const userId in hydrationReminders) {
    const { startHour, endHour, intervalHours, isPaused, channelId, stats } = hydrationReminders[userId];
    dataToSave[userId] = { startHour, endHour, intervalHours, isPaused, channelId, stats };
  }
  fs.writeFileSync(HYDRATION_DATA_FILE, JSON.stringify(dataToSave, null, 2), 'utf-8');
}

// ------------------ Scheduling Functions ------------------

/**
 * cancelAllRemindersForUser stops all scheduled timeouts for a given user.
 */
function cancelAllRemindersForUser(userId) {
  const data = hydrationReminders[userId];
  if (!data) return;
  if (data.timeouts) {
    data.timeouts.forEach(t => clearTimeout(t));
    data.timeouts = [];
  }
  if (data.midnightTimeout) {
    clearTimeout(data.midnightTimeout);
    data.midnightTimeout = null;
  }
}

/**
 * getReminderChannel fetches the channel (or DM) where reminders should be sent.
 */
async function getReminderChannel(client, userId) {
  const data = hydrationReminders[userId];
  if (!data || !data.channelId) return null;
  if (data.channelId === 'dm') {
    const user = await client.users.fetch(userId).catch(() => null);
    return user ? user.createDM() : null;
  }
  return client.channels.fetch(data.channelId).catch(() => null);
}

/**
 * scheduleHydrationRemindersForToday schedules reminders for a user for the current day.
 * It also sets a timeout to re-schedule reminders at midnight.
 */
async function scheduleHydrationRemindersForToday(client, userId) {
  const data = hydrationReminders[userId];
  if (!data) return;
  const channel = await getReminderChannel(client, userId);
  if (!channel) return;
  const now = new Date();
  let hour = data.startHour;
  const interval = data.intervalHours || 2;
  while (hour <= data.endHour) {
    const reminderTime = new Date();
    reminderTime.setHours(hour, 0, 0, 0);
    if (reminderTime > now) {
      const msUntilReminder = reminderTime - now;
      const timeoutId = setTimeout(() => {
        const d = hydrationReminders[userId];
        if (d && !d.isPaused) {
          const randomMsg = RANDOM_HYDRATION_MESSAGES[Math.floor(Math.random() * RANDOM_HYDRATION_MESSAGES.length)];
          channel.send(`<@${userId}> ${randomMsg} (Scheduled reminder)`);
        }
      }, msUntilReminder);
      data.timeouts.push(timeoutId);
    }
    hour += interval;
  }
  // Schedule a reset at midnight to loop the reminders.
  const nextMidnight = new Date();
  nextMidnight.setHours(24, 0, 0, 0);
  const msUntilMidnight = nextMidnight - now;
  data.midnightTimeout = setTimeout(() => {
    data.timeouts = [];
    scheduleHydrationRemindersForToday(client, userId);
  }, msUntilMidnight);
}

/**
 * startHydrationReminders initializes or updates a user's hydration reminder settings,
 * schedules the reminders, and saves the data persistently.
 */
async function startHydrationReminders(client, userId, startHour, endHour, intervalHours, channelChoice) {
  if (!hydrationReminders[userId]) {
    hydrationReminders[userId] = {
      startHour,
      endHour,
      intervalHours,
      isPaused: false,
      channelId: channelChoice,
      stats: { count: 0, streak: 0, lastHydrated: null },
      timeouts: [],
      midnightTimeout: null
    };
  } else {
    const d = hydrationReminders[userId];
    d.startHour = startHour;
    d.endHour = endHour;
    d.intervalHours = intervalHours;
    d.channelId = channelChoice;
    d.isPaused = false;
  }
  cancelAllRemindersForUser(userId);
  await scheduleHydrationRemindersForToday(client, userId);
  saveHydrationReminders();
}

/**
 * rescheduleAllRemindersOnStartup is used on bot startup to re-schedule reminders for all users.
 */
async function rescheduleAllRemindersOnStartup(client) {
  for (const userId in hydrationReminders) {
    const d = hydrationReminders[userId];
    if (!d.isPaused && d.channelId) {
      await scheduleHydrationRemindersForToday(client, userId);
    }
  }
}

/**
 * onBotReady loads persistent hydration data and re-schedules reminders.
 */
async function onBotReady(client) {
  loadHydrationReminders();
  await rescheduleAllRemindersOnStartup(client);
}

// ------------------ Slash Command Definition ------------------

// Define the /hydrate slash command with multiple subcommands.
const data = new SlashCommandBuilder()
  .setName("hydrate")
  .setDescription("Manage your hydration reminders (study personality only)")
  .addSubcommand(sub =>
    sub
      .setName("start")
      .setDescription("Start hydration reminders")
      .addIntegerOption(o =>
        o.setName("start_hour")
         .setDescription("Hour (0-23) to start")
         .setRequired(true)
      )
      .addIntegerOption(o =>
        o.setName("end_hour")
         .setDescription("Hour (0-23) to end")
         .setRequired(true)
      )
      .addIntegerOption(o =>
        o.setName("interval")
         .setDescription("Interval in hours (default 2)")
         .setRequired(false)
      )
      .addBooleanOption(o =>
        o.setName("dm")
         .setDescription("Send reminders in DMs? Defaults to false")
         .setRequired(false)
      )
  )
  .addSubcommand(sub =>
    sub.setName("stop").setDescription("Stop and clear hydration reminders")
  )
  .addSubcommand(sub =>
    sub.setName("pause").setDescription("Pause hydration reminders")
  )
  .addSubcommand(sub =>
    sub.setName("resume").setDescription("Resume paused hydration reminders")
  )
  .addSubcommand(sub =>
    sub.setName("show").setDescription("Show your current hydration schedule")
  )
  .addSubcommand(sub =>
    sub.setName("drank").setDescription("Log that you hydrated, increments your streak")
  );

// ------------------ Slash Command Handler ------------------

async function run({ interaction }) {
  const userId = interaction.user.id;
  // Enforce that only users with the "study" personality can use hydration commands.
  const personality = userPersonalities.get(userId) || "study";
  if (personality !== "study") {
    return interaction.reply({
      content: "You must have the **study** personality selected to use hydration reminders!",
      ephemeral: true,
    });
  }
  
  // Get the subcommand chosen by the user.
  const sub = interaction.options.getSubcommand();
  const client = interaction.client;

  // Handle each subcommand.
  if (sub === "start") {
    const startHour = interaction.options.getInteger("start_hour");
    const endHour = interaction.options.getInteger("end_hour");
    let interval = interaction.options.getInteger("interval");
    if (!interval || interval < 1) interval = 2;
    const dmChoice = interaction.options.getBoolean("dm") || false;
    // Validate the time range.
    if (startHour < 0 || startHour > 23 || endHour < 0 || endHour > 23 || startHour > endHour) {
      return interaction.reply({
        content: "Invalid time range. Use hours 0-23, with start less than or equal to end.",
        ephemeral: true,
      });
    }
    // Determine whether to send reminders to DMs or the current channel.
    const channelChoice = dmChoice ? "dm" : interaction.channelId;
    await startHydrationReminders(client, userId, startHour, endHour, interval, channelChoice);
    return interaction.reply({
      content: `Hydration reminders set from **${startHour}:00** to **${endHour}:00** every **${interval}** hour(s).${dmChoice ? " (Check your DMs!)" : ""}`,
      ephemeral: true,
    });
  }

  if (sub === "stop") {
    cancelAllRemindersForUser(userId);
    delete hydrationReminders[userId];
    saveHydrationReminders();
    return interaction.reply({ content: "Hydration reminders stopped and cleared.", ephemeral: true });
  }

  if (sub === "pause") {
    const d = hydrationReminders[userId];
    if (!d) {
      return interaction.reply({ content: "No active hydration reminders to pause.", ephemeral: true });
    }
    d.isPaused = true;
    if (d.timeouts) {
      d.timeouts.forEach(t => clearTimeout(t));
      d.timeouts = [];
    }
    saveHydrationReminders();
    return interaction.reply({ content: "Your hydration reminders are now paused.", ephemeral: true });
  }

  if (sub === "resume") {
    const d = hydrationReminders[userId];
    if (!d) {
      return interaction.reply({ content: "No hydration reminders found to resume. Start them first.", ephemeral: true });
    }
    if (!d.isPaused) {
      return interaction.reply({ content: "Your hydration reminders are already running.", ephemeral: true });
    }
    d.isPaused = false;
    cancelAllRemindersForUser(userId);
    await scheduleHydrationRemindersForToday(client, userId);
    saveHydrationReminders();
    return interaction.reply({ content: "Your hydration reminders have resumed.", ephemeral: true });
  }

  if (sub === "show") {
    const d = hydrationReminders[userId];
    if (!d) {
      return interaction.reply({ content: "No hydration reminders configured.", ephemeral: true });
    }
    const { startHour, endHour, intervalHours, isPaused, stats } = d;
    const status = isPaused ? "Paused" : "Active";
    const response = `**Hydration Reminders**\nStart Hour: ${startHour}\nEnd Hour: ${endHour}\nInterval: ${intervalHours || 2}\nStatus: ${status}\n\n**Hydration Stats**\nCount: ${stats?.count ?? 0}\nStreak: ${stats?.streak ?? 0}`;
    return interaction.reply({ content: response, ephemeral: true });
  }

  if (sub === "drank") {
    const d = hydrationReminders[userId];
    if (!d) {
      return interaction.reply({ content: "No hydration reminders set. Start them first.", ephemeral: true });
    }
    const now = Date.now();
    const last = d.stats.lastHydrated || 0;
    const hoursSinceLast = (now - last) / (1000 * 60 * 60);
    if (hoursSinceLast < 6) {
      d.stats.streak += 1;
    } else {
      d.stats.streak = 1;
    }
    d.stats.count += 1;
    d.stats.lastHydrated = now;
    saveHydrationReminders();
    return interaction.reply({ content: `Great job! You've hydrated **${d.stats.count}** times. Your streak is now **${d.stats.streak}**.`, ephemeral: true });
  }
}

module.exports = {
  onBotReady,
  data,
  run,
};
