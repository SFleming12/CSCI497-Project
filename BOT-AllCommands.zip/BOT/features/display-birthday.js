// features/display-birthday.js

// Import the necessary class from discord.js to build a slash command.
const { SlashCommandBuilder } = require("discord.js");
// Import the userPersonalities map to check if the user has the correct personality.
const { userPersonalities } = require("./chatgpt");
// Import the getBirthday function from our birthdayStore module to retrieve the stored birthday.
const { getBirthday } = require("./birthdayStore");

module.exports = {
  // Define the slash command data: name and description.
  data: new SlashCommandBuilder()
    .setName("display-birthday")
    .setDescription("Display your set birthday date"),
  async run({ interaction }) {
    // Retrieve the user's personality; default to "study" if not set.
    const personality = userPersonalities.get(interaction.user.id) || "study";
    // Check if the user's personality is "nice"; only "nice" users can use birthday commands.
    if (personality !== "nice") {
      return interaction.reply({
        content: "You must select the **nice** personality to use `/display-birthday`!",
        ephemeral: true, // Ephemeral: visible only to the user.
      });
    }
    // Get the birthday from the birthdayStore.
    const birthday = getBirthday(interaction.user.id);
    if (birthday) {
      // If a birthday is set, reply with the stored birthday.
      await interaction.reply({
        content: `Your birthday is set to **${birthday}**.`,
        ephemeral: true,
      });
    } else {
      // Otherwise, inform the user that no birthday is set.
      await interaction.reply({
        content: "No birthday set.",
        ephemeral: true,
      });
    }
  },
};
