// main.js
// This is the central entry point of the bot. It registers slash commands, handles events,
// and awards XP for each non-bot message. It integrates leveling, personality-based commands,
// and persistent reminder features.

require('dotenv/config');
const { Client, GatewayIntentBits, REST, Routes } = require('discord.js');
// Import our file-based leveling store.
const levelStore = require('./features/levelStore');

// Import core fallback features for help and ChatGPT.
const { handleHelpCommands } = require('./features/help');
const { handleChatGpt, userPersonalities } = require('./features/chatgpt');

// Import slash commands for witty personality.
const eightBall = require('./features/eightBall');
const roast = require('./features/roast');
const fortune = require('./features/fortune');
const banter = require('./features/banter');

// Import slash commands for study personality.
const hydration = require('./features/hydration');
const pomodoro = require('./features/pomodoro');

// Import slash commands for nice personality.
const compliment = require('./features/compliment');
const tellDadJoke = require('./features/tell-dad-joke');
const setBirthday = require('./features/set-birthday');
const removeBirthday = require('./features/remove-birthday');
const editBirthday = require('./features/edit-birthday');
const displayBirthday = require('./features/display-birthday');

// Import stoic personality commands.
const obstacle = require('./features/obstacle');
const philosophy = require('./features/philosophy');

// Import personality selection command.
const selectPersonality = require('./features/selectPersonality');

// Import birthday reminder job.
const birthdayReminder = require('./features/birthdayReminder');

// Import leveling commands.
const level = require('./level');
const resetlevel = require('./resetlevel');
const setLevel = require('./set-level');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.once('ready', async () => {
  console.log("Bot is online");

  // Load persistent data for hydration and pomodoro, then reschedule their reminders/timers.
  await hydration.onBotReady(client);
  pomodoro.loadPomodoroData();
  pomodoro.rescheduleAllPomodoros(client);
  // Start the birthday reminder job to check birthdays daily.
  birthdayReminder.setupBirthdayReminders(client);

  // Register all slash commands using guild-based registration for instant availability.
  const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
  const commandsData = [
    // Witty commands.
    eightBall.data.toJSON(),
    roast.data.toJSON(),
    fortune.data.toJSON(),
    banter.data.toJSON(),
    // Study commands.
    hydration.data.toJSON(),
    pomodoro.data.toJSON(),
    // Nice commands.
    compliment.data.toJSON(),
    tellDadJoke.data.toJSON(),
    setBirthday.data.toJSON(),
    removeBirthday.data.toJSON(),
    editBirthday.data.toJSON(),
    displayBirthday.data.toJSON(),
    // Stoic commands.
    obstacle.data.toJSON(),
    philosophy.data.toJSON(),
    // Personality selection.
    selectPersonality.data.toJSON(),
    // Leveling commands.
    level.data.toJSON(),
    resetlevel.data.toJSON(),
    setLevel.data.toJSON()
  ];

  try {
    console.log("Registering slash commands (guild)...");
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commandsData }
    );
    console.log("Slash commands registered successfully (guild)!");
  } catch (error) {
    console.error("Failed to register slash commands:", error);
  }
});

// Award XP on every non-bot message.
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;

  const userId = message.author.id;
  // Award 10 XP per message.
  let xp = levelStore.getUserXP(userId);
  xp += 10;
  levelStore.setUserXP(userId, xp);
  
  // Level up when XP reaches level * 100 threshold.
  let currentLevel = levelStore.getUserLevel(userId);
  if (xp >= currentLevel * 100) {
    currentLevel++;
    levelStore.setUserLevel(userId, currentLevel);
    // Reset XP to 0 after leveling up.
    levelStore.setUserXP(userId, 0);
    message.channel.send(`<@${userId}> has leveled up to level ${currentLevel}!`);
  }

  // Handle help commands and forward other messages to ChatGPT.
  if (await handleHelpCommands(message)) return;
  await handleChatGpt(message);
});

// Handle all slash command interactions.
client.on('interactionCreate', async (interaction) => {
  if (interaction.isChatInputCommand()) {
    switch (interaction.commandName) {
      // Witty commands.
      case '8ball': return await eightBall.run({ interaction });
      case 'roast': return await roast.run({ interaction });
      case 'fortune': return await fortune.run({ interaction });
      case 'bants': return await banter.run({ interaction });
      // Study commands.
      case 'hydrate': return await hydration.run({ interaction });
      case 'pomodoro': return await pomodoro.run({ interaction });
      // Nice commands.
      case 'compliment': return await compliment.run({ interaction });
      case 'tell-dad-joke': return await tellDadJoke.run({ interaction });
      case 'set-birthday': return await setBirthday.run({ interaction });
      case 'remove-birthday': return await removeBirthday.run({ interaction });
      case 'edit-birthday': return await editBirthday.run({ interaction });
      case 'display-birthday': return await displayBirthday.run({ interaction });
      // Stoic commands.
      case 'obstacle': return await obstacle.run({ interaction });
      case 'philosophy': return await philosophy.run({ interaction });
      // Personality selection.
      case 'select-personality': return await selectPersonality.run({ interaction });
      // Leveling commands.
      case 'level': return await level.run({ interaction });
      case 'resetlevel': return await resetlevel.run({ interaction });
      case 'set-level': return await setLevel.run({ interaction });
      default: return;
    }
  }
  
  // Handle the personality selection dropdown.
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId.startsWith('select-personality-')) {
      const selectedValue = interaction.values[0];
      // Save the selected personality in the userPersonalities map.
      userPersonalities.set(interaction.user.id, selectedValue);
      return await interaction.reply({
        content: `Your personality is now set to **${selectedValue}**!`,
        ephemeral: true,
      });
    }
  }
});

client.login(process.env.TOKEN);
