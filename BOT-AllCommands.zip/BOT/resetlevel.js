// resetlevel.js
// This file defines the /resetlevel slash command which resets a user's level and XP to 1.
// It is restricted to administrators only.

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
// Import the resetUser function from the levelStore to update the persistent store.
const { resetUser } = require('./features/levelStore');

module.exports = {
  // Define the slash command with name, description, and a required user option.
  data: new SlashCommandBuilder()
    .setName('resetlevel')
    .setDescription("Resets a user's level and XP to 1 (Admin only).")
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user whose level will be reset')
        .setRequired(true)
    ),
  run: async ({ interaction }) => {
    // Check for administrator permissions.
    if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
      return interaction.reply({ content: "You don't have permission to use this command.", ephemeral: true });
    }
    // Get the target user from the command options.
    const targetUser = interaction.options.getUser('user');
    // Reset the user's level and XP in the persistent store.
    resetUser(targetUser.id);
    await interaction.reply({ content: `Successfully reset <@${targetUser.id}>'s level and XP.`, ephemeral: false });
  },
};
