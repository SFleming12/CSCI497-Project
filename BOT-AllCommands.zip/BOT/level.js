// level.js
// This file defines the /level slash command that displays a user's current level and XP.
// It uses functions from levelStore.js to retrieve persistent leveling data.

const { SlashCommandBuilder } = require('discord.js');
// Import functions to get the user's level and XP from the file-based store.
const { getUserLevel, getUserXP } = require('./features/levelStore');

module.exports = {
  // Define the slash command data with a name and description.
  data: new SlashCommandBuilder()
    .setName('level')
    .setDescription("Check your current level and XP."),
  run: async ({ interaction }) => {
    // Determine the user's ID from the interaction. This works for both interactions and guild member interactions.
    const userId = interaction.user?.id || interaction.member?.user?.id;
    if (!userId)
      return interaction.reply("I couldn't determine your user ID. Please try again.");
    
    // Retrieve the user's level and XP from the persistent store.
    const level = getUserLevel(userId);
    const xp = getUserXP(userId);
    
    // Reply to the interaction with the current level and XP.
    await interaction.reply(`<@${userId}>, you are currently at level ${level} with ${xp} XP!`);
  },
};
