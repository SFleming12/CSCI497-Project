// features/edit-birthday.js

const { SlashCommandBuilder } = require("discord.js");
const { userPersonalities } = require("./chatgpt");
const { setBirthday } = require("./birthdayStore");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("edit-birthday")
    .setDescription("Edit your set birthday date"),
  async run({ interaction }) {
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply({
        content: "You must select the **nice** personality to use `/edit-birthday`!",
        ephemeral: true,
      });
    }
    await interaction.reply({
      content: "Enter your new birthday in MM-DD format:",
      ephemeral: true,
    });
    const filter = (msg) => msg.author.id === interaction.user.id;
    const collected = await interaction.channel.awaitMessages({
      filter,
      time: 60000,
      max: 1,
    });
    if (collected.size === 0) {
      return interaction.followUp("Time's up! Please try again.");
    }
    const newBirthday = collected.first().content.trim();
    const birthdayRegex = /^\d{2}-\d{2}$/;
    if (!birthdayRegex.test(newBirthday)) {
      return interaction.followUp("Invalid format! Please use MM-DD format.");
    }
    setBirthday(interaction.user.id, newBirthday);
    await interaction.followUp(`Your birthday has been updated to **${newBirthday}**.`);
  },
};
