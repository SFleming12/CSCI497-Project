// features/banter.js

const { SlashCommandBuilder } = require("discord.js");
const { OpenAI } = require("openai");
const { userPersonalities } = require("./chatgpt");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_KEY, // ensure this matches your .env variable
});

module.exports = {
  data: new SlashCommandBuilder()
    .setName("bants")
    .setDescription("Playfully roast yourself or someone else based on a message.")
    .addStringOption(option =>
      option
        .setName("message")
        .setDescription("The message to roast, could be about anything!")
        .setRequired(true)
    ),

  async run(context) {
    // Grab the interaction from context
    const discordInteraction = context.interaction || context;
    if (!discordInteraction) return;

    // Ensure we can read the "message" string option
    if (
      !discordInteraction.options ||
      typeof discordInteraction.options.getString !== "function"
    ) {
      console.error("Interaction options are not available.");
      return "Something went wrong: command options are not available.";
    }

    // The user-supplied message to 'roast'
    const userMessage = discordInteraction.options.getString("message");
    if (!userMessage) {
      await discordInteraction.reply("Please provide a message to roast!");
      return;
    }

    // Check personality
    const selectedPersonality = userPersonalities.get(discordInteraction.user.id);
    if (selectedPersonality !== "witty") {
      await discordInteraction.reply({
        content: "You must select the **witty** personality to use `/bants`!",
        ephemeral: true
      });
      return;
    }

    // Optionally defer
    if (typeof discordInteraction.deferReply === "function") {
      await discordInteraction.deferReply();
    }

    const targetUser = discordInteraction.user;
    const bantsPrompt = `Generate a witty, playful roast based on the following message by ${targetUser.username}: "${userMessage}". Keep it fun, lighthearted, and clever but not offensive. This roast should be something that could be said in a friendly banter between friends.`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [{ role: "system", content: bantsPrompt }],
      });
      const bants = response.choices[0].message.content;

      if (typeof discordInteraction.editReply === "function") {
        await discordInteraction.editReply(`🔥${bants}`);
      } else {
        return `🔥 **Bants**: ${bants}`;
      }
    } catch (error) {
      console.error("OpenAI Error:", error);
      if (typeof discordInteraction.editReply === "function") {
        await discordInteraction.editReply("Oops! I failed to deliver the bants.");
      } else {
        return "Oops! I failed to deliver the bants.";
      }
    }
  },
};
