// features/birthdayReminder.js

const { OpenAI } = require("openai");
const { getAllBirthdays } = require("./birthdayStore");
const openai = new OpenAI({ apiKey: process.env.OPENAI_KEY });

async function checkBirthdays(client) {
  const birthdays = getAllBirthdays();
  const today = new Date();
  const month = String(today.getMonth() + 1).padStart(2, "0");
  const day = String(today.getDate()).padStart(2, "0");
  const todayStr = `${month}-${day}`;

  for (const userId in birthdays) {
    const birthday = birthdays[userId];
    if (birthday.trim() === todayStr) {
      try {
        const user = await client.users.fetch(userId);
        const response = await openai.chat.completions.create({
          model: "gpt-3.5-turbo",
          messages: [
            { role: "system", content: "Generate a cheerful and heartfelt birthday message." },
            { role: "user", content: `Generate a birthday message for ${user.username}` }
          ],
        });
        const birthdayMessage = response.choices[0].message.content;
        // Send birthday message in a designated channel or DM (for this example, we'll DM the user)
        user.send(`Happy Birthday, ${user.username}! ${birthdayMessage}`);
      } catch (error) {
        console.error("Error sending birthday message for user", userId, error);
      }
    }
  }
}

function setupBirthdayReminders(client) {
  const now = new Date();
  const nextCheck = new Date();
  nextCheck.setHours(0, 5, 0, 0); // Check daily at 12:05 AM
  if (nextCheck < now) {
    nextCheck.setDate(nextCheck.getDate() + 1);
  }
  const delay = nextCheck - now;
  setTimeout(() => {
    checkBirthdays(client);
    setInterval(() => {
      checkBirthdays(client);
    }, 24 * 60 * 60 * 1000);
  }, delay);
}

module.exports = {
  setupBirthdayReminders,
};
