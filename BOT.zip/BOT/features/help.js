// features/help.js

function getHelpText() {
  return (
    "**List of Commands:**\n\n" +
    "**Study Personality Only:**\n" +
    "/hydrate [start | stop | pause | resume | show | drank]\n" +
    "→ Manage your hydration reminders (persistent and loop daily).\n" +
    "pomodoro [duration] [repeat]\n" +
    "→ Start a Pomodoro timer (if repeat is true, it loops continuously).\n\n" +
    "**Witty Personality Only:**\n" +
    "/8ball [question], /roast @User, /fortune, /bants [message]\n\n" +
    "**Nice Personality Only:**\n" +
    "/compliment, /tell-dad-joke\n" +
    "/set-birthday, /remove-birthday, /edit-birthday, /display-birthday\n\n" +
    "**/select-personality**\n" +
    "→ Choose your personality (study, witty, nice, etc.).\n\n" +
    "**(Anything else)**\n" +
    "→ Forwarded to ChatGPT with your chosen personality.\n"
  );
}

async function handleHelpCommands(message) {
  const lower = message.content.trim().toLowerCase();
  if (lower === 'help' || lower === 'help menu') {
    await message.reply(getHelpText());
    return true;
  }
  return false;
}

module.exports = {
  handleHelpCommands
};
