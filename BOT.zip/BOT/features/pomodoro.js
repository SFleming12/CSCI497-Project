// features/pomodoro.js

const { SlashCommandBuilder } = require("discord.js");
const fs = require("fs");
const path = require("path");
const { userPersonalities } = require("./chatgpt");

const POMODORO_DATA_FILE = path.join(__dirname, '..', 'pomodoroData.json');
let pomodoroData = {}; // userId -> { duration, repeat, nextSession, timeoutId }

function loadPomodoroData() {
  if (fs.existsSync(POMODORO_DATA_FILE)) {
    try {
      pomodoroData = JSON.parse(fs.readFileSync(POMODORO_DATA_FILE, "utf-8"));
    } catch (err) {
      console.error("Error parsing pomodoroData.json:", err);
    }
  }
}

function savePomodoroData() {
  fs.writeFileSync(POMODORO_DATA_FILE, JSON.stringify(pomodoroData, null, 2), "utf-8");
}

function clearPomodoroTimeout(userId) {
  if (pomodoroData[userId] && pomodoroData[userId].timeoutId) {
    clearTimeout(pomodoroData[userId].timeoutId);
    pomodoroData[userId].timeoutId = null;
  }
}

function schedulePomodoro(client, userId) {
  const data = pomodoroData[userId];
  if (!data) return;
  const now = Date.now();
  const delay = Math.max(data.nextSession - now, 0);
  data.timeoutId = setTimeout(async () => {
    try {
      const user = await client.users.fetch(userId);
      user.send(`Your Pomodoro session of ${data.duration} minute(s) is over! Time for a break.`);
    } catch (err) {
      console.error("Failed to send Pomodoro message:", err);
    }
    if (data.repeat) {
      data.nextSession = Date.now() + data.duration * 60 * 1000;
      schedulePomodoro(client, userId);
    } else {
      delete pomodoroData[userId];
    }
    savePomodoroData();
  }, delay);
}

function rescheduleAllPomodoros(client) {
  for (const userId in pomodoroData) {
    schedulePomodoro(client, userId);
  }
}

const data = new SlashCommandBuilder()
  .setName("pomodoro")
  .setDescription("Start a Pomodoro timer (study personality only)")
  .addIntegerOption(option =>
    option
      .setName("duration")
      .setDescription("Duration in minutes (default 25)")
      .setRequired(false)
  )
  .addBooleanOption(option =>
    option
      .setName("repeat")
      .setDescription("Repeat the timer continuously")
      .setRequired(false)
  );

async function run({ interaction }) {
  const personality = userPersonalities.get(interaction.user.id) || "study";
  if (personality !== "study") {
    return interaction.reply({
      content: "You must have the **study** personality selected to use Pomodoro!",
      ephemeral: true
    });
  }

  if (typeof interaction.deferReply === "function") {
    await interaction.deferReply({ ephemeral: true });
  }

  const duration = interaction.options.getInteger("duration") || 25;
  const repeat = interaction.options.getBoolean("repeat") || false;
  const userId = interaction.user.id;

  clearPomodoroTimeout(userId);
  pomodoroData[userId] = {
    duration,
    repeat,
    nextSession: Date.now() + duration * 60 * 1000,
    timeoutId: null
  };

  schedulePomodoro(interaction.client, userId);
  savePomodoroData();

  return interaction.editReply({
    content: `Pomodoro timer started for ${duration} minute(s)! ${repeat ? "It will repeat continuously until stopped." : ""}`,
    ephemeral: true
  });
}

module.exports = {
  data,
  run,
  loadPomodoroData,
  rescheduleAllPomodoros
};
