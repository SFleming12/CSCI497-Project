// features/compliment.js

const { SlashCommandBuilder } = require("discord.js");
const { OpenAI } = require("openai");
const { userPersonalities } = require("./chatgpt");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_KEY,
});

module.exports = {
  data: new SlashCommandBuilder()
    .setName("compliment")
    .setDescription("Give a compliment to the user"),

  async run({ interaction }) {
    // 1) personality check
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply("You must select the **nice** personality to use `/compliment`!");
    }

    // 2) Generate the compliment
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "Generate a random compliment to make someone feel good about themselves.",
          },
          {
            role: "user",
            content: `Give a compliment to ${interaction.user.username}`,
          },
        ],
      });

      const compliment = response.choices[0].message.content;
      await interaction.reply(`${interaction.user}, ${compliment}`);
    } catch (error) {
      console.error("Error generating compliment with OpenAI:", error);
      await interaction.reply(
        "Oops, something went wrong while generating your compliment. Please try again later."
      );
    }
  },
};
