// features/tell-dad-joke.js

const { SlashCommandBuilder } = require("discord.js");
const { OpenAI } = require("openai");
const { userPersonalities } = require("./chatgpt");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_KEY,
});

module.exports = {
  data: new SlashCommandBuilder()
    .setName("tell-dad-joke")
    .setDescription("Tell a dad joke to the user"),

  async run({ interaction }) {
    // Check personality
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply("You must select the **nice** personality to use `/tell-dad-joke`!");
    }

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "Generate a random dad joke.",
          },
          {
            role: "user",
            content: `Tell a dad joke to ${interaction.user.username}`,
          },
        ],
      });

      const dadJoke = response.choices[0].message.content;
      await interaction.reply(`${interaction.user}, ${dadJoke}`);
    } catch (error) {
      console.error("Error generating a dad joke with OpenAI:", error);
      await interaction.reply(
        "Oops, something went wrong while generating your dad joke. Please try again later."
      );
    }
  },
};
