// features/birthdayStore.js

const fs = require('fs');
const path = require('path');
const BIRTHDAY_DATA_FILE = path.join(__dirname, '..', 'birthdayData.json');

function loadBirthdays() {
  if (!fs.existsSync(BIRTHDAY_DATA_FILE)) return {};
  try {
    return JSON.parse(fs.readFileSync(BIRTHDAY_DATA_FILE, 'utf-8'));
  } catch (err) {
    console.error("Failed to parse birthdayData.json:", err);
    return {};
  }
}

function saveBirthdays(data) {
  fs.writeFileSync(BIRTHDAY_DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

function setBirthday(userId, birthday) {
  const data = loadBirthdays();
  data[userId] = birthday;
  saveBirthdays(data);
}

function removeBirthday(userId) {
  const data = loadBirthdays();
  if (data[userId]) {
    delete data[userId];
    saveBirthdays(data);
    return true;
  }
  return false;
}

function getBirthday(userId) {
  const data = loadBirthdays();
  return data[userId];
}

function getAllBirthdays() {
  return loadBirthdays();
}

module.exports = {
  setBirthday,
  removeBirthday,
  getBirthday,
  getAllBirthdays,
};
