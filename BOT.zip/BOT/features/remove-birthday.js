// features/remove-birthday.js

const { SlashCommandBuilder } = require("discord.js");
const { userPersonalities } = require("./chatgpt");
const { removeBirthday } = require("./birthdayStore");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("remove-birthday")
    .setDescription("Remove your set birthday date"),
  async run({ interaction }) {
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply({
        content: "You must select the **nice** personality to use `/remove-birthday`!",
        ephemeral: true,
      });
    }
    const success = removeBirthday(interaction.user.id);
    if (success) {
      await interaction.reply({
        content: "Your birthday has been removed successfully.",
        ephemeral: true,
      });
    } else {
      await interaction.reply({
        content: "No birthday found to remove.",
        ephemeral: true,
      });
    }
  },
};
