// features/set-birthday.js

const { SlashCommandBuilder } = require("discord.js");
const { userPersonalities } = require("./chatgpt");
const { setBirthday } = require("./birthdayStore");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("set-birthday")
    .setDescription("Set your birthday date (MM-DD) for birthday announcements"),
  async run({ interaction }) {
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply({
        content: "You must select the **nice** personality to use `/set-birthday`!",
        ephemeral: true,
      });
    }
    await interaction.reply({
      content: "Please enter your birthday in MM-DD format:",
      ephemeral: true,
    });
    const filter = (msg) => msg.author.id === interaction.user.id;
    const collected = await interaction.channel.awaitMessages({
      filter,
      time: 60000,
      max: 1,
    });
    if (collected.size === 0) {
      return interaction.followUp("Time's up! Please try again.");
    }
    const birthdayInput = collected.first().content.trim();
    const birthdayRegex = /^\d{2}-\d{2}$/;
    if (!birthdayRegex.test(birthdayInput)) {
      return interaction.followUp("Invalid format! Please use MM-DD format.");
    }
    setBirthday(interaction.user.id, birthdayInput);
    await interaction.followUp(`Your birthday has been set to **${birthdayInput}**.`);
  },
};
