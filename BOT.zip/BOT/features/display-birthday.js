// features/display-birthday.js

const { SlashCommandBuilder } = require("discord.js");
const { userPersonalities } = require("./chatgpt");
const { getBirthday } = require("./birthdayStore");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("display-birthday")
    .setDescription("Display your set birthday date"),
  async run({ interaction }) {
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply({
        content: "You must select the **nice** personality to use `/display-birthday`!",
        ephemeral: true,
      });
    }
    const birthday = getBirthday(interaction.user.id);
    if (birthday) {
      await interaction.reply({
        content: `Your birthday is set to **${birthday}**.`,
        ephemeral: true,
      });
    } else {
      await interaction.reply({
        content: "No birthday set.",
        ephemeral: true,
      });
    }
  },
};
