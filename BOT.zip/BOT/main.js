require('dotenv/config');
const { Client, GatewayIntentBits, REST, Routes } = require('discord.js');

// Import text-based and ChatGPT fallback features
const { handleHelpCommands } = require('./features/help');
const { handleChatGpt, userPersonalities } = require('./features/chatgpt');

// Import slash-based witty features (require "witty")
const eightBall = require('./features/eightBall');
const roast = require('./features/roast');
const fortune = require('./features/fortune');
const banter = require('./features/banter');

// Import slash-based study features (require "study")
const hydration = require('./features/hydration');
const pomodoro = require('./features/pomodoro');

// Import birthday features (require "nice")
const compliment = require('./features/compliment');
const tellDadJoke = require('./features/tell-dad-joke');
const setBirthday = require('./features/set-birthday');
const removeBirthday = require('./features/remove-birthday');
const editBirthday = require('./features/edit-birthday');
const displayBirthday = require('./features/display-birthday');

// Personality selection (available to all)
const selectPersonality = require('./features/selectPersonality');

// Birthday reminder background job (reads from birthdayData.json)
const birthdayReminder = require('./features/birthdayReminder');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

client.once('ready', async () => {
  console.log("Bot is online");

  // Load hydration and pomodoro persistent data and reschedule reminders
  await hydration.onBotReady(client);
  pomodoro.loadPomodoroData();
  pomodoro.rescheduleAllPomodoros(client);

  // Setup birthday reminders (runs daily)
  birthdayReminder.setupBirthdayReminders(client);

  // Register slash commands (using guild registration for instant updates)
  const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
  const commandsData = [
    eightBall.data.toJSON(),
    roast.data.toJSON(),
    fortune.data.toJSON(),
    banter.data.toJSON(),
    hydration.data.toJSON(),
    pomodoro.data.toJSON(),
    selectPersonality.data.toJSON(),
    compliment.data.toJSON(),
    tellDadJoke.data.toJSON(),
    setBirthday.data.toJSON(),
    removeBirthday.data.toJSON(),
    editBirthday.data.toJSON(),
    displayBirthday.data.toJSON()
  ];

  try {
    console.log("Registering slash commands (guild)...");
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commandsData }
    );
    console.log("Slash commands registered successfully (guild)!");
  } catch (error) {
    console.error("Failed to register slash commands:", error);
  }
});

client.on('interactionCreate', async (interaction) => {
  if (interaction.isChatInputCommand()) {
    switch (interaction.commandName) {
      // Witty commands (require "witty")
      case '8ball': return await eightBall.run({ interaction });
      case 'roast': return await roast.run({ interaction });
      case 'fortune': return await fortune.run({ interaction });
      case 'bants': return await banter.run({ interaction });
      
      // Study commands (require "study")
      case 'hydrate': return await hydration.run({ interaction });
      case 'pomodoro': return await pomodoro.run({ interaction });
      
      // Nice commands (require "nice")
      case 'compliment': return await compliment.run({ interaction });
      case 'tell-dad-joke': return await tellDadJoke.run({ interaction });
      case 'set-birthday': return await setBirthday.run({ interaction });
      case 'remove-birthday': return await removeBirthday.run({ interaction });
      case 'edit-birthday': return await editBirthday.run({ interaction });
      case 'display-birthday': return await displayBirthday.run({ interaction });
      
      // Personality selection (common)
      case 'select-personality': return await selectPersonality.run({ interaction });
      default: return;
    }
  }

  if (interaction.isStringSelectMenu()) {
    if (interaction.customId.startsWith('select-personality-')) {
      const selectedValue = interaction.values[0];
      userPersonalities.set(interaction.user.id, selectedValue);
      await interaction.reply({
        content: `Your personality is now set to **${selectedValue}**!`,
        ephemeral: true
      });
    }
  }
});

// Text-based commands for help and ChatGPT fallback
client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (await handleHelpCommands(message)) return;
  await handleChatGpt(message);
});

client.login(process.env.TOKEN);
