// Required libraries
require("dotenv/config");
const { Client, GatewayIntentBits, REST, Routes } = require("discord.js");
const fs = require("fs");

// Import file-based leveling store
const levelStore = require("./features/levelStore");

// Import core fallback features for help and ChatGPT
const { handleHelpCommands } = require("./features/help");
const { handleChatGpt, userPersonalities } = require("./features/chatgpt");

// Import slash commands for witty personality
const eightBall = require("./features/eightBall");
const roast = require("./features/roast");
const fortune = require("./features/fortune");
const banter = require("./features/banter");

// Import slash commands for study personality
const hydration = require("./features/hydration");
const pomodoro = require("./features/pomodoro");

// Import slash commands for nice personality
const compliment = require("./features/compliment");
const tellDadJoke = require("./features/tell-dad-joke");
const setBirthday = require("./features/set-birthday");
const removeBirthday = require("./features/remove-birthday");
const editBirthday = require("./features/edit-birthday");
const displayBirthday = require("./features/display-birthday");

// Import stoic personality commands
const obstacle = require("./features/obstacle");
const philosophy = require("./features/philosophy");

// Import personality selection command
const selectPersonality = require("./features/selectPersonality");

// Import leveling commands
const level = require("./features/level");
const resetlevel = require("./features/reset-level");
const setLevel = require("./features/set-level");

// Import level 3 command
const ping = require("./features/ping");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// Registering slash commands (Fixed)
client.once("ready", async () => {
  console.log("Bot is online");

  const clientId = client.user.id;
  const guilds = client.guilds.cache.map((guild) => guild.id);
  const rest = new REST({ version: "10" }).setToken(process.env.TOKEN);

  // Commands Data (without set-channel command)
  const commandsData = [
    ping.data.toJSON(),
    eightBall.data.toJSON(),
    roast.data.toJSON(),
    fortune.data.toJSON(),
    banter.data.toJSON(),
    hydration.data.toJSON(),
    pomodoro.data.toJSON(),
    compliment.data.toJSON(),
    tellDadJoke.data.toJSON(),
    setBirthday.data.toJSON(),
    removeBirthday.data.toJSON(),
    editBirthday.data.toJSON(),
    displayBirthday.data.toJSON(),
    obstacle.data.toJSON(),
    philosophy.data.toJSON(),
    selectPersonality.data.toJSON(),
    level.data.toJSON(),
    resetlevel.data.toJSON(),
    setLevel.data.toJSON(),
  ];

  try {
    // Clear old commands before registering the new ones
    for (const guildId of guilds) {
      console.log(`Clearing existing commands for guild: ${guildId}`);
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
        body: [],
      });
    }

    console.log("Old commands cleared successfully!");

    // Register new commands
    for (const guildId of guilds) {
      console.log(`Registering new commands for guild: ${guildId}`);
      await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
        body: commandsData,
      });
    }
    console.log("Slash commands registered successfully!");
  } catch (error) {
    console.error("Failed to register slash commands:", error);
  }
});

// Award XP on every non-bot message
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const userId = message.author.id;
  let xp = levelStore.getUserXP(userId);
  xp += 10;
  levelStore.setUserXP(userId, xp);

  let currentLevel = levelStore.getUserLevel(userId);
  if (xp >= currentLevel * 100) {
    currentLevel++;
    levelStore.setUserLevel(userId, currentLevel);
    levelStore.setUserXP(userId, 0);
    message.channel.send(
      `<@${userId}> has leveled up to level ${currentLevel}!`
    );
  }

  if (await handleHelpCommands(message)) return;
  await handleChatGpt(message);
});

// Handle all slash command interactions
client.on("interactionCreate", async (interaction) => {
  if (interaction.isChatInputCommand()) {
    // Handle other commands
    const commandMap = {
      ping: ping,
      "8ball": eightBall,
      roast: roast,
      fortune: fortune,
      bants: banter,
      hydrate: hydration,
      pomodoro: pomodoro,
      compliment: compliment,
      "tell-dad-joke": tellDadJoke,
      "set-birthday": setBirthday,
      "remove-birthday": removeBirthday,
      "edit-birthday": editBirthday,
      "display-birthday": displayBirthday,
      obstacle: obstacle,
      philosophy: philosophy,
      "select-personality": selectPersonality,
      level: level,
      "reset-level": resetlevel,
      "set-level": setLevel,
    };

    const command = commandMap[interaction.commandName];
    if (command) {
      return await command.run({ interaction, client });
    }
  }

  // Handle the personality selection dropdown
  if (interaction.isStringSelectMenu()) {
    if (interaction.customId.startsWith("select-personality-")) {
      const selectedValue = interaction.values[0];
      userPersonalities.set(interaction.user.id, selectedValue);

      // Call the avatar change function
      await selectPersonality.changeAvatar(selectedValue, client);

      return await interaction.reply({
        content: `Your personality is now set to **${selectedValue}**!`,
        ephemeral: true,
      });
    }
  }
});

// Login the bot
client.login(process.env.TOKEN);
