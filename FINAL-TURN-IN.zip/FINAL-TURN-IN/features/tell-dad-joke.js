// features/tell-dad-joke.js

// Import the SlashCommandBuilder to define a slash command.
const { SlashCommandBuilder } = require("discord.js");
// Import OpenAI to generate the dad joke.
const { OpenAI } = require("openai");
// Import userPersonalities to ensure the command is only used by "nice" users.
const { userPersonalities } = require("./chatgpt");

// Create an OpenAI client instance.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_KEY,
});

module.exports = {
  // Define the slash command for telling a dad joke.
  data: new SlashCommandBuilder()
    .setName("tell-dad-joke")
    .setDescription("Tell a dad joke to the user"),

  async run({ interaction }) {
    // Check if the user has the "nice" personality.
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply("You must select the **nice** personality to use `/tell-dad-joke`!");
    }

    try {
      // Request a dad joke from OpenAI.
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "Generate a random dad joke.",
          },
          {
            role: "user",
            content: `Tell a dad joke to ${interaction.user.username}`,
          },
        ],
      });

      // Extract the dad joke from the response.
      const dadJoke = response.choices[0].message.content;
      // Reply to the interaction with the generated dad joke.
      await interaction.reply(`${interaction.user}, ${dadJoke}`);
    } catch (error) {
      console.error("Error generating a dad joke with OpenAI:", error);
      await interaction.reply(
        "Oops, something went wrong while generating your dad joke. Please try again later."
      );
    }
  },
};
