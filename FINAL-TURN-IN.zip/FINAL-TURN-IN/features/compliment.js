// features/compliment.js

// Import necessary classes from discord.js.
const { SlashCommandBuilder } = require("discord.js");
// Import OpenAI to generate compliments.
const { OpenAI } = require("openai");
// Import the userPersonalities map to check if the user has selected the correct personality.
const { userPersonalities } = require("./chatgpt");

// Create an OpenAI client instance.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_KEY,
});

module.exports = {
  // Define the slash command for compliment.
  data: new SlashCommandBuilder()
    .setName("compliment")
    .setDescription("Give a compliment to the user"),

  async run({ interaction }) {
    // Check if the user's personality is "nice". If not, deny access.
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply(
        "You must select the **nice** personality to use `/compliment`!"
      );
    }

    try {
      // Request a compliment from OpenAI using the GPT-3.5-turbo model.
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content:
              "Generate a random compliment to make someone feel good about themselves.",
          },
          {
            role: "user",
            content: `Give a compliment to ${interaction.user.username}`,
          },
        ],
      });

      // Extract the compliment text from the API response.
      const compliment = response.choices[0].message.content;
      // Reply to the user with the generated compliment.
      await interaction.reply(`${interaction.user}, ${compliment}`);
    } catch (error) {
      console.error("Error generating compliment with OpenAI:", error);
      await interaction.reply(
        "Oops, something went wrong while generating your compliment. Please try again later."
      );
    }
  },
};
