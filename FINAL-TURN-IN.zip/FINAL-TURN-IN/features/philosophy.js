// features/philosophy.js

// Import the builder for slash commands from discord.js.
const { SlashCommandBuilder } = require("discord.js");
// Import the OpenAI library to generate content.
const { OpenAI } = require("openai");
// Import userPersonalities map to check the user's selected personality.
const { userPersonalities } = require("./chatgpt");

// Create an OpenAI client using the API key from your .env file.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_KEY,
});

module.exports = {
  // Define the slash command: /philosophy generates a random philosophical quote.
  data: new SlashCommandBuilder()
    .setName("philosophy")
    .setDescription("Generates a random philosophical quote."),
  run: async ({ interaction }) => {
    // Retrieve the user's selected personality (default to an empty string if none).
    const personality = userPersonalities.get(interaction.user.id) || "";
    // Ensure that only users with the "stoic" personality can use this command.
    if (personality.toLowerCase() !== "stoic") {
      return interaction.reply({
        content: "You must select the **stoic** personality to use this command.",
        ephemeral: true,
      });
    }
    try {
      // Send a request to the OpenAI API with a system prompt and user message.
      const response = await openai.chat.completions.create({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a philosopher who provides deep, thought-provoking quotes.",
          },
          {
            role: "user",
            content: "Give me a random philosophical quote.",
          },
        ],
      });
      // Extract the generated quote from the response.
      const quote = response.choices[0].message.content;
      // Reply to the interaction with the quote.
      await interaction.reply(quote);
    } catch (error) {
      // Log any error and notify the user.
      console.error(error);
      await interaction.reply("Sorry, I couldn't generate a quote at this time.");
    }
  },
};
