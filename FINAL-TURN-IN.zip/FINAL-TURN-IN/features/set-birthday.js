// features/set-birthday.js
const { SlashCommandBuilder } = require("discord.js");
const { userPersonalities } = require("./chatgpt"); // Ensure this import is correct
const { setBirthday } = require("./birthdayStore");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("set-birthday")
    .setDescription("Set your birthday date (MM-DD) for birthday announcements")
    .addStringOption((option) =>
      option
        .setName("birthday")
        .setDescription("Your birthday in MM-DD format (e.g., 03-16)")
        .setRequired(true)
    ),
  async run({ interaction }) {
    // Check that the user has the "nice" personality.
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply({
        content:
          "You must select the **nice** personality to use `/set-birthday`!",
        ephemeral: true,
      });
    }

    const birthdayInput = interaction.options.getString("birthday").trim();

    // Validate the format (MM-DD).
    const birthdayRegex = /^\d{2}-\d{2}$/;
    if (!birthdayRegex.test(birthdayInput)) {
      return interaction.reply({
        content: "Invalid format! Please use MM-DD format.",
        ephemeral: true,
      });
    }

    // Save the birthday using the birthdayStore.
    setBirthday(interaction.user.id, birthdayInput);

    // Confirm the update to the user.
    return interaction.reply({
      content: `Your birthday has been set to **${birthdayInput}**.`,
      ephemeral: true,
    });
  },
};
