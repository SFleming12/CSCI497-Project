// features/selectPersonality.js

// Import the necessary builders from discord.js.
const {
  SlashCommandBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  ActionRowBuilder,
} = require("discord.js");

// Define the slash command for selecting personality.
const data = new SlashCommandBuilder()
  .setName("select-personality")
  .setDescription("Choose the chatbot's personality using a select menu");

async function run({ interaction }) {
  // Define the list of available personalities.
  const personalities = [
    {
      label: "Study Partner",
      value: "study",
      description: "A helpful chatbot that loves to help you study.",
    },
    {
      label: "Witty",
      value: "witty",
      description: "A chatbot with clever jokes and humor.",
    },
    {
      label: "Nice",
      value: "nice",
      description: "A warm, friendly chatbot who loves positivity.",
    },
    {
      label: "Stoic",
      value: "stoic",
      description: "A calm, composed chatbot offering stoic wisdom.",
    },
  ];

  // Create a select menu with the personality options.
  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId(`select-personality-${interaction.id}`)
    .setPlaceholder("Choose a chatbot personality...")
    .setMaxValues(1)
    .addOptions(
      personalities.map((p) =>
        new StringSelectMenuOptionBuilder()
          .setLabel(p.label)
          .setDescription(p.description)
          .setValue(p.value)
      )
    );

  // Add the select menu to an action row.
  const actionRow = new ActionRowBuilder().addComponents(selectMenu);
  // Reply with the select menu (ephemeral so only the user sees it).
  await interaction.reply({ components: [actionRow], ephemeral: true });
}

// Handle the avatar change based on personality selection
async function changeAvatar(personality, client) {
  let newAvatar = "SageGradient.png"; // Default avatar is the gradient

  // Set the avatar based on the personality
  if (personality === "witty") {
    newAvatar = "SageNegative.png"; // Negative image for witty
  } else if (personality === "study" || personality === "stoic") {
    newAvatar = "SageNeutral.png"; // Neutral image for study and stoic
  } else if (personality === "nice") {
    newAvatar = "SagePositive.png"; // Positive image for nice
  }

  // Check if the new avatar is different from the current one and update it
  const currentAvatarURL = client.user
    .displayAvatarURL({ format: "png", size: 1024 })
    .split("?")[0];
  if (!currentAvatarURL.includes(newAvatar)) {
    try {
      await client.user.setAvatar(newAvatar);
      console.log("Avatar updated successfully.");
    } catch (error) {
      console.error("Error changing avatar:", error);
    }
  }
}

module.exports = { data, run, changeAvatar };
