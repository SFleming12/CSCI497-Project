const { SlashCommandBuilder } = require("discord.js");
const { getUserLevel } = require("./levelStore"); // Import the level fetching function

module.exports = {
  data: new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Replies with Pong!"),
  run: async ({ interaction, client }) => {
    if (!client || !client.ws) {
      return interaction.reply({
        content: "Error: WebSocket connection is unavailable.",
        ephemeral: true,
      });
    }

    const userId = interaction.user?.id || interaction.member?.user?.id;
    if (!userId) {
      return interaction.reply({
        content: "I couldn't determine your user ID.",
        ephemeral: true,
      });
    }

    let level = getUserLevel(userId) || 1;

    if (level < 3) {
      return interaction.reply({
        content: "You must be level 3 or higher to use this command!",
        ephemeral: true,
      });
    }

    await interaction.reply(`:ping_pong: Pong! ${client.ws.ping}ms`);
  },
};
