// features/edit-birthday.js

const { SlashCommandBuilder } = require("discord.js");
const { userPersonalities } = require("./chatgpt"); // Ensure this import is correct
const { setBirthday } = require("./birthdayStore");

module.exports = {
  // Define the slash command with a name and description.
  data: new SlashCommandBuilder()
    .setName("edit-birthday")
    .setDescription("Edit your set birthday date")
    .addStringOption((option) =>
      option
        .setName("new-birthday")
        .setDescription("Enter your new birthday in MM-DD format (e.g., 03-16)")
        .setRequired(true)
    ),
  async run({ interaction }) {
    // Check if the user's personality is "nice"; required for birthday commands.
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply({
        content:
          "You must select the **nice** personality to use `/edit-birthday`!",
        ephemeral: true,
      });
    }

    const newBirthday = interaction.options.getString("new-birthday").trim();

    // Validate the birthday format (MM-DD).
    const birthdayRegex = /^\d{2}-\d{2}$/;
    if (!birthdayRegex.test(newBirthday)) {
      return interaction.reply({
        content: "Invalid format! Please use MM-DD format.",
        ephemeral: true,
      });
    }

    // Update the birthday in the persistent store.
    setBirthday(interaction.user.id, newBirthday);

    // Inform the user of the successful update.
    return interaction.reply({
      content: `Your birthday has been updated to **${newBirthday}**.`,
      ephemeral: true,
    });
  },
};
