// features/obstacle.js

// Import the SlashCommandBuilder to define the command.
const { SlashCommandBuilder } = require("discord.js");
// Import userPersonalities to ensure the command is only available to stoic users.
const { userPersonalities } = require("./chatgpt");

module.exports = {
  // Define the slash command with its name, description, and a required string option.
  data: new SlashCommandBuilder()
    .setName("obstacle")
    .setDescription("Share an obstacle you are facing, and receive a Stoic response on how to deal with it.")
    .addStringOption(option =>
      option
        .setName("obstacle")
        .setDescription("Describe the obstacle you are facing.")
        .setRequired(true)
    ),
  async run({ interaction }) {
    // Retrieve the user's personality and ensure it is "stoic".
    const personality = userPersonalities.get(interaction.user.id) || "";
    if (personality.toLowerCase() !== "stoic") {
      return interaction.reply({
        content: "You must select the **stoic** personality to use this command.",
        ephemeral: true,
      });
    }

    // Get the obstacle input from the command.
    const obstacle = interaction.options.getString("obstacle");
    // Generate a Stoic response based on the obstacle.
    const stoicResponse = generateStoicResponse(obstacle);
    // Reply to the interaction with the generated response.
    await interaction.reply(stoicResponse);
  },
};

/**
 * generateStoicResponse: Returns a randomly selected Stoic-inspired message
 * based on the obstacle provided.
 */
function generateStoicResponse(obstacle) {
  const stoicQuotes = [
    "What is within our power is our judgment, our actions, and our reactions. Focus on what you can control, and let go of what you can't.",
    "The obstacle on your path is not an enemy but an opportunity for growth. Embrace it as a chance to cultivate strength and resilience.",
    "Remember, the mind that is disturbed by external events is the mind that has not yet mastered itself. Keep your peace within, regardless of the obstacle.",
    "It is not the events themselves that disturb us, but our judgments about them. Reframe your thinking to focus on solutions, not problems.",
    "Just as a stone is polished by friction, a soul is strengthened by adversity. Do not shy away from challenges, but use them to improve."
  ];
  const randomResponse = stoicQuotes[Math.floor(Math.random() * stoicQuotes.length)];
  return `You mentioned the obstacle: *"${obstacle}"*. Here's a Stoic response for you:\n\n"${randomResponse}"`;
}
