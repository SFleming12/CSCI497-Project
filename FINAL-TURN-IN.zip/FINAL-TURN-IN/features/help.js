// features/help.js

/**
 * getHelpText returns a string that lists all the available commands
 * and their personality requirements.
 */
function getHelpText() {
  return (
    "**List of Commands:**\n\n" +
    "**Study Personality Only:**\n" +
    "/hydrate [start | stop | pause | resume | show | drank] → Manage hydration reminders.\n" +
    "/pomodoro [duration] [repeat] → Start a Pomodoro timer.\n\n" +
    "**Witty Personality Only:**\n" +
    "/8ball [question], /roast @User, /fortune, /bants [message]\n\n" +
    "**Nice Personality Only:**\n" +
    "/compliment, /tell-dad-joke, /set-birthday [Date], /remove-birthday, /edit-birthday [Date], /display-birthday\n\n" +
    "**Stoic Personality Only:**\n" +
    "/obstacle [obstacle] → Receive Stoic advice on your obstacle.\n" +
    "/philosophy → Get a random philosophical quote.\n\n" +
    "**/select-personality** → Choose your personality (study, witty, nice, stoic).\n\n" +
    "**Leveling System:**\n" +
    "/level, /reset-level @user, /set-level @user [level] \n\n" +
    "**Level 3 or Above Users Only:**\n" +
    "/ping\n\n" +
    "**(Anything else)** → Forwarded to ChatGPT with your chosen personality.\n"
  );
}

/**
 * handleHelpCommands checks if a message is "help" or "help menu" and replies with the help text.
 */
async function handleHelpCommands(message) {
  const lower = message.content.trim().toLowerCase();
  if (lower === "help" || lower === "help menu") {
    await message.reply(getHelpText());
    return true;
  }
  return false;
}

module.exports = {
  handleHelpCommands,
};
