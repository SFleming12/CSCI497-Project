// set-level.js
// This file defines the /set-level slash command which allows administrators to set a user's level to a specific value.
// It resets the XP to 0 as part of the level change.

const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
// Import setUserLevel and setUserXP functions from the levelStore.
const { setUserLevel, setUserXP } = require("./levelStore");

module.exports = {
  // Define the slash command with a user option and an integer option for the new level.
  data: new SlashCommandBuilder()
    .setName("set-level")
    .setDescription("Sets a user's level to a specified value (Admin only).")
    .addUserOption((option) =>
      option
        .setName("user")
        .setDescription("The user whose level will be changed")
        .setRequired(true)
    )
    .addIntegerOption((option) =>
      option
        .setName("level")
        .setDescription("The new level to set (must be 1 or higher)")
        .setRequired(true)
    ),
  run: async ({ interaction }) => {
    // Check if the member has Administrator permission.
    if (
      !interaction.member.permissions.has(PermissionFlagsBits.Administrator)
    ) {
      return interaction.reply({
        content: "You don't have permission to use this command.",
        ephemeral: true,
      });
    }
    // Get the target user and new level from the options.
    const targetUser = interaction.options.getUser("user");
    const newLevel = interaction.options.getInteger("level");
    if (newLevel < 1) {
      return interaction.reply({
        content: "Level must be 1 or higher.",
        ephemeral: true,
      });
    }
    // Set the user's level and reset their XP.
    setUserLevel(targetUser.id, newLevel);
    setUserXP(targetUser.id, 0);
    await interaction.reply({
      content: `Successfully set <@${targetUser.id}>'s level to ${newLevel} and reset their XP.`,
      ephemeral: false,
    });
  },
};
