// features/pomodoro.js

// Import the necessary classes from discord.js.
const { SlashCommandBuilder } = require("discord.js");
// Import file system and path modules for persistent data storage.
const fs = require("fs");
const path = require("path");
// Import userPersonalities to enforce the "study" personality requirement.
const { userPersonalities } = require("./chatgpt");

// Define the file path for storing pomodoro data persistently.
const POMODORO_DATA_FILE = path.join(__dirname, '..', 'pomodoroData.json');
// In-memory storage for pomodoro sessions: maps userId to session data.
let pomodoroData = {};

/**
 * loadPomodoroData loads pomodoro session data from the JSON file.
 */
function loadPomodoroData() {
  if (fs.existsSync(POMODORO_DATA_FILE)) {
    try {
      pomodoroData = JSON.parse(fs.readFileSync(POMODORO_DATA_FILE, "utf-8"));
    } catch (err) {
      console.error("Error parsing pomodoroData.json:", err);
    }
  }
}

/**
 * savePomodoroData writes the current pomodoro session data to the JSON file.
 */
function savePomodoroData() {
  fs.writeFileSync(POMODORO_DATA_FILE, JSON.stringify(pomodoroData, null, 2), "utf-8");
}

/**
 * clearPomodoroTimeout clears any scheduled timeout for a user's pomodoro session.
 */
function clearPomodoroTimeout(userId) {
  if (pomodoroData[userId] && pomodoroData[userId].timeoutId) {
    clearTimeout(pomodoroData[userId].timeoutId);
    pomodoroData[userId].timeoutId = null;
  }
}

/**
 * schedulePomodoro schedules a pomodoro session reminder for a user.
 * When the timer expires, it sends a DM and, if repeat is true, reschedules itself.
 */
function schedulePomodoro(client, userId) {
  const data = pomodoroData[userId];
  if (!data) return;
  const now = Date.now();
  const delay = Math.max(data.nextSession - now, 0);
  data.timeoutId = setTimeout(async () => {
    try {
      const user = await client.users.fetch(userId);
      // DM the user notifying that their pomodoro session is over.
      user.send(`Your Pomodoro session of ${data.duration} minute(s) is over! Time for a break.`);
    } catch (err) {
      console.error("Failed to send Pomodoro message:", err);
    }
    // If repeat is enabled, schedule the next session; otherwise, remove the session.
    if (data.repeat) {
      data.nextSession = Date.now() + data.duration * 60 * 1000;
      schedulePomodoro(client, userId);
    } else {
      delete pomodoroData[userId];
    }
    savePomodoroData();
  }, delay);
}

/**
 * rescheduleAllPomodoros iterates through all stored pomodoro sessions and schedules them.
 */
function rescheduleAllPomodoros(client) {
  for (const userId in pomodoroData) {
    schedulePomodoro(client, userId);
  }
}

// Define the slash command for Pomodoro.
const data = new SlashCommandBuilder()
  .setName("pomodoro")
  .setDescription("Start a Pomodoro timer (study personality only)")
  .addIntegerOption(option =>
    option
      .setName("duration")
      .setDescription("Duration in minutes (default 25)")
      .setRequired(false)
  )
  .addBooleanOption(option =>
    option
      .setName("repeat")
      .setDescription("Repeat the timer continuously")
      .setRequired(false)
  );

/**
 * run handles the pomodoro slash command:
 * - Checks that the user's personality is "study."
 * - Retrieves the options and starts the timer.
 */
async function run({ interaction }) {
  const personality = userPersonalities.get(interaction.user.id) || "study";
  if (personality !== "study") {
    return interaction.reply({
      content: "You must have the **study** personality selected to use Pomodoro!",
      ephemeral: true,
    });
  }

  // Defer the reply to allow time for processing.
  if (typeof interaction.deferReply === "function") {
    await interaction.deferReply({ ephemeral: true });
  }

  // Get the duration (default 25 minutes) and repeat flag.
  const duration = interaction.options.getInteger("duration") || 25;
  const repeat = interaction.options.getBoolean("repeat") || false;
  const userId = interaction.user.id;

  // Clear any existing pomodoro timer for the user.
  clearPomodoroTimeout(userId);
  // Store the new pomodoro session data.
  pomodoroData[userId] = {
    duration,
    repeat,
    nextSession: Date.now() + duration * 60 * 1000,
    timeoutId: null,
  };

  // Schedule the pomodoro session.
  schedulePomodoro(interaction.client, userId);
  // Save the session data to disk.
  savePomodoroData();

  return interaction.editReply({
    content: `Pomodoro timer started for ${duration} minute(s)! ${repeat ? "It will repeat continuously until stopped." : ""}`,
    ephemeral: true,
  });
}

module.exports = {
  data,
  run,
  loadPomodoroData,
  rescheduleAllPomodoros,
};
