// features/set-birthday.js

// Import the SlashCommandBuilder to create a slash command.
const { SlashCommandBuilder } = require("discord.js");
// Import userPersonalities to enforce that only "nice" users can use birthday commands.
const { userPersonalities } = require("./chatgpt");
// Import the setBirthday function from birthdayStore to persist the birthday.
const { setBirthday } = require("./birthdayStore");

module.exports = {
  // Define the slash command for setting the birthday.
  data: new SlashCommandBuilder()
    .setName("set-birthday")
    .setDescription("Set your birthday date (MM-DD) for birthday announcements"),
  async run({ interaction }) {
    // Check that the user has the "nice" personality.
    const personality = userPersonalities.get(interaction.user.id) || "study";
    if (personality !== "nice") {
      return interaction.reply({
        content: "You must select the **nice** personality to use `/set-birthday`!",
        ephemeral: true,
      });
    }
    // Ask the user to input their birthday.
    await interaction.reply({
      content: "Please enter your birthday in MM-DD format:",
      ephemeral: true,
    });
    // Create a filter so that only messages from the command user are accepted.
    const filter = (msg) => msg.author.id === interaction.user.id;
    // Wait for the user's reply (up to 1 minute).
    const collected = await interaction.channel.awaitMessages({
      filter,
      time: 60000,
      max: 1,
    });
    if (collected.size === 0) {
      return interaction.followUp("Time's up! Please try again.");
    }
    // Get the birthday input and trim any extra whitespace.
    const birthdayInput = collected.first().content.trim();
    // Validate the format (MM-DD).
    const birthdayRegex = /^\d{2}-\d{2}$/;
    if (!birthdayRegex.test(birthdayInput)) {
      return interaction.followUp("Invalid format! Please use MM-DD format.");
    }
    // Save the birthday using the birthdayStore.
    setBirthday(interaction.user.id, birthdayInput);
    // Confirm the update to the user.
    await interaction.followUp(`Your birthday has been set to **${birthdayInput}**.`);
  },
};
